#    This file is part of EAP.
#
#    EAP is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Lesser General Public License as
#    published by the Free Software Foundation, either version 3 of
#    the License, or (at your option) any later version.
#
#    EAP is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#    GNU Lesser General Public License for more details.
#
#    You should have received a copy of the GNU Lesser General Public
#    License along with EAP. If not, see <http://www.gnu.org/licenses/>.

import operator
import math
import random
# import string
import numpy

from deap import algorithms
from deap import base
from deap import creator
from deap import tools
from deap import gp

# Define new functions
def protectedDiv(left, right):
    try:
        return left / right
    except ZeroDivisionError:
        return 1

pset = gp.PrimitiveSet("MAIN", 9)
pset.addPrimitive(operator.add, 2)
pset.addPrimitive(operator.sub, 2)
pset.addPrimitive(operator.mul, 2)
pset.addPrimitive(protectedDiv, 2)
pset.addPrimitive(operator.neg, 1)
pset.addPrimitive(math.cos, 1)
pset.addPrimitive(math.sin, 1)


pset.addEphemeralConstant("rand101", lambda: random.randint(-20,20))
pset.renameArguments(ARG0='x0')
pset.renameArguments(ARG1='x1')
pset.renameArguments(ARG2='x2')
pset.renameArguments(ARG3='x3')
pset.renameArguments(ARG4='x4')
pset.renameArguments(ARG5='x5')
pset.renameArguments(ARG6='x6')
pset.renameArguments(ARG7='x7')
pset.renameArguments(ARG8='x8')




creator.create("FitnessMin", base.Fitness, weights=(1.0,))
creator.create("Individual", gp.PrimitiveTree, fitness=creator.FitnessMin)

toolbox = base.Toolbox()
toolbox.register("expr", gp.genHalfAndHalf, pset=pset, min_=1, max_=2)
toolbox.register("individual", tools.initIterate, creator.Individual, toolbox.expr)
toolbox.register("population", tools.initRepeat, list, toolbox.individual)
toolbox.register("compile", gp.compile, pset=pset)

   

def loadData(fname):
    with open(fname,'r') as fp:
        temp_rows=[]
        for line in fp:
            if "?" in line:
                index = line.find("?")
                s = list(line)
                if index>0:
                    s[index]='-1'
                line = "".join(s)
            line.strip("\n")
            cid,c0,c1,c2,c3,c4,c5,c6,c7,c8,cla=line.split(",")
            row=[int(c0),int(c1),int(c2),int(c3),int(c4),int(c5),int(c6),int(c7),int(c8),int(cla)]
            temp_rows.append(row)
        return temp_rows
rows=loadData("train.txt")
test_rows=loadData("test.txt")

def evalSymbReg(individual, pointRows):
    # Transform the tree expression in a callable function
    func = toolbox.compile(expr=individual)
    # Evaluate the mean squared error between the expression
    # and the real function : 
    # print "ind ",individual
    thred=1
    predictClas=0
    noCorrect1=0.0
    noCorrect2=0.0
    noClass1=0.0
    noClass2=0.0
    for pointAtt in pointRows:
        tempAtt=pointAtt[:9]
        classLabel= pointAtt[9]
        # print "tempAtt:",tempAtt
        # print "classLabel: ",classLabel
        if classLabel==2:
            noClass1+=1
        else:
            noClass2+=1
        if func(*tempAtt)>thred:
            predictClas=2
        else:
            predictClas=4
        if classLabel==predictClas:
            if classLabel==2:
                noCorrect1+=1.0
            else:
                noCorrect2+=1.0
    accurarcy=(noCorrect1/noClass1 + noCorrect2/noClass2)/2.0

    # print "acc:",accurarcy
    return accurarcy,

toolbox.register("evaluate", evalSymbReg, pointRows=rows)

toolbox.register("select", tools.selTournament, tournsize=3)
toolbox.register("mate", gp.cxOnePoint)
toolbox.register("expr_mut", gp.genFull, min_=0, max_=2)
toolbox.register("mutate", gp.mutUniform, expr=toolbox.expr_mut, pset=pset)

toolbox.decorate("mate", gp.staticLimit(key=operator.attrgetter("height"), max_value=17))
toolbox.decorate("mutate", gp.staticLimit(key=operator.attrgetter("height"), max_value=17))

def main():
    # random.seed(18)
    # random.seed(118)
    random.seed(218)
    # random.seed(318)
    # random.seed(418)
    # random.seed(518)
    # random.seed(618)
    # random.seed(718)
    # random.seed(818)
    # random.seed(918)
   
   
    pop = toolbox.population(n=1024)
    hof = tools.HallOfFame(1)
    
    stats_fit = tools.Statistics(lambda ind: ind.fitness.values)
    stats_size = tools.Statistics(len)
    mstats = tools.MultiStatistics(fitness=stats_fit, size=stats_size)
    mstats.register("avg", numpy.mean)
    mstats.register("std", numpy.std)
    mstats.register("min", numpy.min)
    mstats.register("max", numpy.max)

    pop, log = algorithms.eaSimple(pop, toolbox, 0.3, 0.3, 75, stats=mstats,
                                  halloffame=hof, verbose=True)
    print hof[0]
    print hof[0].fitness
    accuracy = evalSymbReg(hof[0], test_rows)
    print "predict: ",accuracy
    return pop, log, hof

if __name__ == "__main__":
    main()
