Using termianl to run the part3 programe.

Enter under part3/deap-master/examples/gp folder in terminal First,
Then,following the below command: 

python classfication.py 


(Notice using python2 instead of python3.) In your terminal, you probably using 

python2 classfication.py 
