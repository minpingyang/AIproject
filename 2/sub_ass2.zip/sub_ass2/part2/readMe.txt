Using termianl to run the part2 programe.

Enter under part2/deap-master/examples/gp folder in terminal First,
Then,following the below command: 

python regression.py


(Notice using python2 instead of python3.) In your terminal, you probably using 

python2 regression.py
