Using termianl to run the part1 programe.

Enter uner part1/bpnn folder in terminal First,

Then,following the below commands:


./nntrain iris.net iris.pat  
./nntest iris.net iris.pat weights.dat

