Using termianl to run the naive.py programe.

Enter under ass3 folder in terminal First,
Then,following the below command: 

python naive.py 


(Notice using python2 instead of python3.) In your terminal, you probably using 

python2 naive.py
